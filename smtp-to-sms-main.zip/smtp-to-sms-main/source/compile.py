import py_compile
py_compile.compile('main.py')
# the compiled file will be saved as yourfile.pyc in a __pycache__ folder, which will be created the same folder as yourfile.py