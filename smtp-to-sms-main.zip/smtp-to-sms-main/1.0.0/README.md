
# SMTP TO SMS SENDER

This Scripts is used to use sms messages with email services utilizing the email gateway provided by sms carriers


## Authors

- [@hackeinstein](https://www.github.com/Hackeinstein)


## Installation

Install the required python modules

```bash
  pip install colorama
  pip install numpy
```
    
## Features

- Multi SMTP / Threading     features
- New improved ssl connectivity with certifi
- Hotwords swaping and randomizer
- Message limiter
- Faster and Better


## Demo
The script is easy to use just set your required parameters and run all error would be saves in the log.txt for refernce purposes



## Key Feature

- using hot swapable word or randomiser there are only four supported, fill the info of each in the content folder
- [company] [link] [amount] [word] are the only dynamic call tags load your list in the text files associated to each and pass in the parameters for amount
- initate the randomiser by loading the list and putting the call tag in your content the script would detect and do the rest
-
![App Screenshot](https://i.ibb.co/mFzk2g3/demo.png)

